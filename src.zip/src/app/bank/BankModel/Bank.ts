export interface Bank {
    Account_No:string,
    Date:string,
    Transaction_Details:string,
    Value_Date:string,
    Withdrawal_AMT:string,
    Deposit_AMT:string,
    Balance_AMT:string,
}